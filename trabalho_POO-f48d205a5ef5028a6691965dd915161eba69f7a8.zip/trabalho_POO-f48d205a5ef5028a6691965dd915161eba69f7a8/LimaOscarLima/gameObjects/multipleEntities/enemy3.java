package LimaOscarLima.gameObjects.multipleEntities;

public class enemy3 extends enemy1{

    public enemy3(double enemies_radius, long enemiesSpawnTime) {
        super(enemies_radius, enemiesSpawnTime);
    }
}
